# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pokemon_nerd', 'tests']

package_data = \
{'': ['*'],
 'pokemon_nerd': ['data/*',
                  'data/pocketsphinx/1827.dic',
                  'data/pocketsphinx/1827.dic',
                  'data/pocketsphinx/1827.lm',
                  'data/pocketsphinx/1827.lm',
                  'data/pocketsphinx/acoustic-model/*']}

install_requires = \
['pocketsphinx>=5.0.0,<6.0.0',
 'pyaudio>=0.2.12,<0.3.0',
 'speechrecognition>=3.8.1,<4.0.0']

setup_kwargs = {
    'name': 'pokemon-nerd',
    'version': '1.0.5',
    'description': 'A nerdy Pokémon friend you can ask all your questions.',
    'long_description': '',
    'author': 'Cyber Scholar',
    'author_email': '48360032+STARKBOND@users.noreply.github.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
